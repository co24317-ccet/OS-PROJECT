
from utils.edge_trace_loader import generate_edge_trace
import streamlit as st
import pandas as pd
import time

from utils.trace_generator import generate_trace
from utils.metrics import hit_ratio
from simulator.controller import run
from ml.predictor import DummyMLPredictor

st.set_page_config(page_title="ML Page Replacement", layout="wide")

st.title("🧠 ML-Based Page Replacement Simulator")

# Sidebar
st.sidebar.header("⚙️ Configuration")

# --- Trace Source Selection ---
trace_source = st.sidebar.selectbox("Trace Source", ["Synthetic", "Edge Dataset"])

if trace_source == "Edge Dataset":
    uploaded_file = st.sidebar.file_uploader("Upload VM_CPU.csv")
    if uploaded_file:
        st.session_state["trace"] = generate_edge_trace(uploaded_file)

frames = st.sidebar.slider("Frame Size", 2, 10, 3)
trace_len = st.sidebar.slider("Trace Length", 10, 80, 25)
max_page = st.sidebar.slider("Max Page ID", 5, 50, 10)
locality = st.sidebar.checkbox("Enable Locality", True)

if trace_source == "Synthetic" and st.sidebar.button("Generate New Trace"):
    st.session_state["trace"] = generate_trace(trace_len, max_page, locality)

if "trace" not in st.session_state:
    if trace_source == "Edge Dataset":
        st.session_state["trace"] = []
    else:
        st.session_state["trace"] = generate_trace(trace_len, max_page, locality)

trace = st.session_state["trace"]

st.subheader("📌 Reference String")
st.write(trace)

algo_choice = st.selectbox("Select Algorithm", ["FIFO", "LRU", "ML-Based"])

# Run single simulation
if st.button("▶ Run Simulation"):
    predictor = DummyMLPredictor() if algo_choice == "ML-Based" else None
    faults, steps = run(trace, algo_choice, frames, predictor)

    hr = hit_ratio(faults, len(trace))

    c1, c2, c3 = st.columns(3)
    c1.metric("Page Faults", faults)
    c2.metric("Hit Ratio", f"{hr:.2f}")
    c3.metric("Requests", len(trace))

    st.subheader("🧩 Step-by-Step")
    box = st.empty()
    for s in steps:
        box.markdown(f"**Step {s['step']}**  \nIncoming: `{s['page']}`  \nFrames: {s['frames']}  \n{'❌ Fault' if s['fault'] else '✅ Hit'}")
        time.sleep(0.2)

    if algo_choice == "ML-Based" and predictor:
        acc = predictor.get_accuracy()
        st.subheader("🎯 Prediction Accuracy")
        st.metric("Accuracy", f"{acc*100:.2f}%")
        st.progress(acc)

# Comparison
st.subheader("📊 Comparison")
if st.button("Compare All Algorithms"):
    rows = []
    for name in ["FIFO", "LRU", "ML-Based"]:
        predictor = DummyMLPredictor() if name == "ML-Based" else None
        faults, _ = run(trace, name, frames, predictor)
        rows.append({
            "Algorithm": name,
            "Page Faults": faults,
            "Hit Ratio": hit_ratio(faults, len(trace))
        })
    df = pd.DataFrame(rows)
    st.dataframe(df)
    st.bar_chart(df.set_index("Algorithm")["Page Faults"])
    st.bar_chart(df.set_index("Algorithm")["Hit Ratio"])

# Animated charts
st.subheader("🎬 Animated Comparison")
if st.button("Run Animated Comparison"):
    line_ph = st.empty()
    bar_ph = st.empty()

    algos = ["FIFO", "LRU", "ML-Based"]
    states = {name: {"faults": 0, "predictor": DummyMLPredictor() if name=="ML-Based" else None, "history": []} for name in algos}
    # initialize fresh runs per algo
    from algorithms.fifo import FIFO
    from algorithms.lru import LRU
    from algorithms.ml_policy import MLPolicy

    instances = {
        "FIFO": FIFO(frames),
        "LRU": LRU(frames),
        "ML-Based": MLPolicy(frames, states["ML-Based"]["predictor"])
    }

    progress = {name: [] for name in algos}

    for i, page in enumerate(trace):
        next_page = trace[i+1] if i+1 < len(trace) else None

        for name in algos:
            inst = instances[name]
            if name == "ML-Based":
                hist = states[name]["history"]
                fault = inst.access(hist, page, next_page)
                hist.append(page)
            else:
                fault = inst.access(page)

            if fault:
                states[name]["faults"] += 1

            progress[name].append(states[name]["faults"])

        # update charts
        line_df = pd.DataFrame(progress)
        bar_df = pd.DataFrame([{k: v["faults"] for k, v in states.items()}])
        line_ph.line_chart(line_df)
        bar_ph.bar_chart(bar_df)
        time.sleep(0.15)

# Accuracy over time (ML)
st.subheader("📈 Accuracy Over Time (ML)")
if st.button("Show Accuracy Trend"):
    from ml.predictor import DummyMLPredictor
    pred = DummyMLPredictor()
    history = []
    acc_list = []
    correct = 0
    total = 0

    for i in range(len(trace)-1):
        p = pred.predict(history, trace[i+1])
        history.append(trace[i])
        total += 1
        if p == trace[i+1]:
            correct += 1
        acc_list.append(correct/total)

    st.line_chart(pd.DataFrame({"Accuracy": acc_list}))


# --- Edge Dataset Support ---
import streamlit as st

trace_type = st.sidebar.selectbox("Trace Source", ["Synthetic", "Edge Dataset"])

if trace_type == "Edge Dataset":
    uploaded_file = st.sidebar.file_uploader("Upload VM_CPU.csv")
    if uploaded_file:
        sequence = generate_edge_trace(uploaded_file)
        st.write("Generated sequence length:", len(sequence))
